package burp;

public class Config {
    private static final String EXTENDER_NAME = "xray4burp";
    private static final String EXTENDER_VERSION = "0.31";
    private static String SUFFIX_STR = "";
    private static String XRAY_PATH = "xray";
    private static String REQUST_FILE_PATH = "";
    private static String XRAY_OPTIONS_COMMAND = "webscan --raw-request";
    private static String OS_TYPE;
    private static boolean IS_INJECT = false;


    public static String getExtenderName() {
        return EXTENDER_NAME;
    }

    public static String getExtenderVersion() {
        return EXTENDER_VERSION;
    }

    public static String getSuffixStr() {
        try {
            String val = BurpExtender.callbacks.loadExtensionSetting("SUFFIX_STR");
            if(val == null){
                return Config.SUFFIX_STR;
            }else{
                return val;
            }
        }catch(Exception e){
            return Config.SUFFIX_STR;
        }
    }

    public static void setSuffixStr(String suffixStr) {
        BurpExtender.callbacks.saveExtensionSetting("SUFFIX_STR", String.valueOf(suffixStr));
        Config.XRAY_PATH = suffixStr;
    }

    public static String getXrayPath() {
        try {
            String val = BurpExtender.callbacks.loadExtensionSetting("XRAY_PATH");
            if(val == null){
                return Config.XRAY_PATH;
            }else{
                return val;
            }
        }catch(Exception e){
            return Config.XRAY_PATH;
        }
    }

    public static void setXrayPath(String xrayPath) {
        BurpExtender.callbacks.saveExtensionSetting("XRAY_PATH", String.valueOf(xrayPath));
        Config.XRAY_PATH = xrayPath;
    }

    public static String getRequstFilePath() {
        return REQUST_FILE_PATH;
    }

    public static void setRequstFilePath(String requstFilePath) {
        REQUST_FILE_PATH = requstFilePath;
    }

    public static String getXrayOptionsCommand() {
        try {
            String val = BurpExtender.callbacks.loadExtensionSetting("XRAY_OPTIONS_COMMAND");
            if(val == null){
                return Config.XRAY_OPTIONS_COMMAND;
            }else{
                return val;
            }
        }catch(Exception e){
            return Config.XRAY_OPTIONS_COMMAND;
        }
    }

    public static void setXrayCommand(String xrayOptionsCommand) {
        BurpExtender.callbacks.saveExtensionSetting("XRAY_OPTIONS_COMMAND", String.valueOf(xrayOptionsCommand));
        Config.XRAY_OPTIONS_COMMAND = xrayOptionsCommand;
    }

    public static String getOsType() {
        return OS_TYPE;
    }

    public static void setOsType(String osType) {
        OS_TYPE = osType;
    }

    public static boolean isIsInject() {
        return IS_INJECT;
    }

    public static void setIsInject(boolean isInject) {
        IS_INJECT = isInject;
    }
}
